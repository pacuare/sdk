# Pacuare SDK

This library allows you to query the Pacuare Reserve dataset from Python into a Pandas DataFrame.